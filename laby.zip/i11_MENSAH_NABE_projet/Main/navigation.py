from affichage import *
import random
from extensions import *

def modif_couleur(t, t2, dicojeu):

    #fonction qui change la couleur de la tortue en fonction de la case
	pos=t.position()
	coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
	couleur_de_tortue=dicojeu["couleur de tortue"]
	xcsg=dicojeu["coor_csg"][0]
	ycsg=dicojeu["coor_csg"][1]
	if coor_pos==(dicojeu["Sortie"][0]+1, dicojeu["Sortie"][1]+1 ):
		t.color("green")
		t2.hideturtle()
		t2.penup()
		t2.color("black")
		t2.goto(xcsg,ycsg+20 )
		t2.write("Victoire🎉!!", align="center", font=("Arial", 20, "bold"))
	elif detection_nature_passage(coor_pos[0], coor_pos[1], dicojeu)=="Carrefour":
		t.color("blue")
	elif detection_nature_passage(coor_pos[0], coor_pos[1], dicojeu)=="Impasse":
		t.color("gray")
	else:
		t.color(couleur_de_tortue)







def gauche(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points):
	taille=dicojeu["taille_cel"]
	pos=t.position()
	coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
	lignes=len(dicojeu["labyrinthe"])
	colonnes=len(dicojeu["labyrinthe"][0])
	if (not(0<coor_pos[0]<=lignes) or not(0<coor_pos[1]-1<=colonnes)):
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("Vous ne pouvez pas sortir du labyrinthe", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	elif (typecellule(coor_pos[0], coor_pos[1]-1, dicojeu)!="mur"):
		if t.heading()==180:
			t.forward(taille)
		elif t.heading()==90:
			t.left(90)
			t.forward(taille)
		elif t.heading()==0:
			t.left(180)
			t.forward(taille)
			li[1]+=1
		elif t.heading()==270:
			t.right(90)
			t.forward(taille)
		print("gauche ; left")
		li[0]+=1
		pos=t.position()
		coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
		if (coor_pos[0], coor_pos[1]) in li_piece:
			li[2]+=5
			li_piece.remove((coor_pos[0], coor_pos[1]))
			t4.color("black")
			if detection_nature_passage(coor_pos[0], coor_pos[1], dicojeu)=="Carrefour":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "gold", t4, colonnes, lignes, taille)
			elif typecellule(coor_pos[0], coor_pos[1], dicojeu)=="passage":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "white", t4, colonnes, lignes, taille)
		liste_commande.append("gauche")
			

	else:
		screen.ontimer(t.color("red"), 100)
		t.color(dicojeu["couleur de tortue"])
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("vous ne pouvez pas passer a travers le mur", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	
	modif_couleur(t, t2, dicojeu)
	mise_a_jour_statistiques(label_pas, label_demi_tours, label_points, li[0], li[1], li[2])
	



def droite(t, t2, t4,  dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points):
	taille=dicojeu["taille_cel"]
	pos=t.position()
	coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
	lignes=len(dicojeu["labyrinthe"])
	colonnes=len(dicojeu["labyrinthe"][0])
	if (not(0<coor_pos[0]<=lignes) or not(0<coor_pos[1]+1<=colonnes)):
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("Vous ne pouvez pas sortir du labyrinthe", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	elif (typecellule(coor_pos[0], coor_pos[1]+1, dicojeu)!="mur"):
		if t.heading()==180:
			t.right(180)
			t.forward(taille)
			li[1]+=1
		elif t.heading()==90:
			t.right(90)
			t.forward(taille)
		elif t.heading()==0:
			t.forward(taille)
		elif t.heading()==270:
			t.left(90)
			t.forward(taille)
		print("droite ; right")
		pos=t.position()
		coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
		if (coor_pos[0], coor_pos[1]) in li_piece:
			li[2]+=5
			t4.color("black")
			li_piece.remove((coor_pos[0], coor_pos[1]))
			if detection_nature_passage(coor_pos[0], coor_pos[1], dicojeu)=="Carrefour":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "gold", t4, colonnes, lignes, taille)
			elif typecellule(coor_pos[0], coor_pos[1], dicojeu)=="passage":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "white", t4, colonnes, lignes, taille)
		li[0]+=1
		liste_commande.append("droite")
	else:
		screen.ontimer(t.color("red"), 100)
		t.color(dicojeu["couleur de tortue"])
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("Vous ne pouvez pas passer a travers le mur", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	
	modif_couleur(t, t2, dicojeu)
	mise_a_jour_statistiques(label_pas, label_demi_tours, label_points, li[0], li[1], li[2])




def bas(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points):
	lignes=len(dicojeu["labyrinthe"])
	colonnes=len(dicojeu["labyrinthe"][0])
	taille=dicojeu["taille_cel"]
	pos=t.position()
	coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
	if (not(0<coor_pos[0]+1<=lignes) or not(0<coor_pos[1]<=colonnes)):
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("Vous ne pouvez pas sortir du labyrinthe", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	elif typecellule(coor_pos[0]+1, coor_pos[1], dicojeu)!="mur" :
		if t.heading()==180:
			t.left(90)
			t.forward(taille)
		elif t.heading()==90:
			t.left(180)
			t.forward(taille)
			li[1]+=1
		elif t.heading()==0:
			t.right(90)
			t.forward(taille)
		elif t.heading()==270:
			t.forward(taille)
		print("bas ; down")
		li[0]+=1
		pos=t.position()
		coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
		if (coor_pos[0], coor_pos[1]) in li_piece:
			li[2]+=5
			t4.color("black")
			li_piece.remove((coor_pos[0], coor_pos[1]))
			if detection_nature_passage(coor_pos[0], coor_pos[1], dicojeu)=="Carrefour":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "gold", t4, colonnes, lignes, taille)
			elif typecellule(coor_pos[0], coor_pos[1], dicojeu)=="passage":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "white", t4, colonnes, lignes, taille)
		liste_commande.append("bas")
	else:
		screen.ontimer(t.color("red"), 100)
		t.color(dicojeu["couleur de tortue"])
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("vous ne pouvez pas passer a travers le mur", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	
	modif_couleur(t, t2, dicojeu)
	mise_a_jour_statistiques(label_pas, label_demi_tours, label_points, li[0], li[1], li[2])



def haut(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points):
	lignes=len(dicojeu["labyrinthe"])
	colonnes=len(dicojeu["labyrinthe"][0])
	taille=dicojeu["taille_cel"]
	pos=t.position()
	coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)

	if (not(0<coor_pos[0]-1<=lignes) or not(0<coor_pos[1]<=colonnes)):
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("Vous ne pouvez pas sortir du labyrinthe", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
	elif typecellule(coor_pos[0]-1, coor_pos[1], dicojeu)!="mur" :
		if t.heading()==180:
			t.right(90)
			t.forward(taille)
		elif t.heading()==90:
			t.forward(taille)
		elif t.heading()==0:
			t.left(90)
			t.forward(taille)
		elif t.heading()==270:
			t.right(180)
			t.forward(taille)
			li[1]+=1
		
		print("haut ; up")
		li[0]+=1
		pos=t.position()
		coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
		if (coor_pos[0], coor_pos[1]) in li_piece:
			li[2]+=5
			t4.color("black")
			li_piece.remove((coor_pos[0], coor_pos[1]))
			if detection_nature_passage(coor_pos[0], coor_pos[1], dicojeu)=="Carrefour":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "gold", t4, colonnes, lignes, taille)
			elif typecellule(coor_pos[0], coor_pos[1], dicojeu)=="passage":
				dessiner_case(coor_pos[1]-1, coor_pos[0]-1, "white", t4, colonnes, lignes, taille)
		liste_commande.append("haut")
	else:
		screen.ontimer(t.color("red"), 100)
		t.color(dicojeu["couleur de tortue"])
		t4.up()
		t4.goto(0, -280)
		screen.ontimer(t4.write("vous ne pouvez pas passer a travers le mur", align="center", font=("Arial", 11, "bold")), 250)
		t4.undo()
		
	modif_couleur(t, t2, dicojeu)
	mise_a_jour_statistiques(label_pas, label_demi_tours, label_points, li[0], li[1], li[2])


def suivre_commande(li, t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen , li_stat, label_pas, label_demi_tours, li_piece, label_points):
	xcsg=dicojeu["coor_csg"][0]
	ycsg=dicojeu["coor_csg"][1]
	pos=t.position()
	i=0
	pos_actu=(0.0, 0.0)
	while i<len(li) and pos!=pos_actu:
		pos=t.position()
		if li[i]=="gauche":
			gauche(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, li_piece, label_points)
		elif li[i]=="droite":
			droite(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, li_piece, label_points)
		elif li[i]=="haut":
			haut(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, li_piece, label_points)
		elif li[i]=="bas":
			bas(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, li_piece, label_points)
		pos_actu=t.position()
		i+=1 
		if (pos==pos_actu) and (i<len(li)):
			t3.hideturtle()
			t3.penup()
			t3.goto(xcsg, ycsg+20)
			return t3.write("Impossible d'évoluer ", align="center", font=("Arial", 20, "bold"))

def inverserchemin(li, t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, li_piece, label_points):
    copie=list(li)
    for i in range(len(copie)//2):
        copie[i], copie[-1-i]=copie[-1-i], copie[i]
    for j in range(len(copie)):
        if copie[j]=='gauche':
            copie[j]='droite'
        elif copie[j]=='droite':
            copie[j]='gauche'
        elif copie[j]=='bas':
            copie[j]='haut'
        elif copie[j]=='haut':
            copie[j]='bas'

    suivre_commande(copie, t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, li_piece, label_points)


def explorer(t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points, debut, fin):
	li=[0, 0, 0] ###reinitialisation des statistiques
	x=debut[0]+1
	y=debut[1]+1
	t.speed(1000)
	t.goto(cell2pixel(x, y, dicojeu))
	t.speed(1)
	t.showturtle()
	lignes=len(dicojeu["labyrinthe"])
	colonnes=len(dicojeu["labyrinthe"][0])
	chemin=[(x, y)]
	while (x, y)!= (fin[0]+1, fin[1]+1) :
		if (detection_nature_passage(x, y, dicojeu)!="Carrefour" and detection_nature_passage(x, y, dicojeu)!="Impasse") or (x==debut[0]+1 and y==debut[1]+1):
			voisins=[(x, y+1), (x, y-1), (x+1, y), (x-1, y)]
			choix=[(vx, vy) for vx, vy in voisins if (typecellule(vx, vy, dicojeu)!="mur" and (0<vx<=lignes) and (0<vy<=colonnes))]
			l=0
			while l<len(choix):
				if choix[l] in chemin:
					choix.remove(choix[l])
				else:
					l+=1
			if len(choix)==0:
				direc=chemin[-2]
			else:
				direc=random.choice(choix)
			if direc==(x, y-1):
				gauche(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours,li_piece, label_points)
			elif direc==(x, y+1):
				droite(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
			elif direc==(x-1, y):
				haut(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
			elif direc==(x+1, y):
				bas(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
			chemin.append(direc)


		elif detection_nature_passage(x, y, dicojeu)=="Impasse":
			copie=[]
			chemin_impasse=[]
			j=1
			while detection_nature_passage(chemin[-1 * j][0], chemin[-1 * j][1], dicojeu)!="Carrefour":
				chemin_impasse.append(chemin[-1 * j])
				j+=1
			chemin_impasse.append(chemin[-1 * j])
			x_prec=chemin_impasse[0][0]
			y_prec=chemin_impasse[0][1]
			for i in range (1, len(chemin_impasse)):
				if chemin_impasse[i][0]==x_prec:
					if chemin_impasse[i][1]==y_prec+1:
						copie.append('droite')
					elif chemin_impasse[i][1]==y_prec-1:
						copie.append('gauche')
				elif chemin_impasse[i][1]==y_prec:
					if chemin_impasse[i][0]==x_prec+1:
						copie.append('bas')
					elif chemin_impasse[i][0]==x_prec-1:
						copie.append('haut')
				x_prec=chemin_impasse[i][0]
				y_prec=chemin_impasse[i][1]
			suivre_commande(copie, t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
			for i in chemin_impasse:
				chemin.append(i)


		elif detection_nature_passage(x, y, dicojeu)=="Carrefour":
			voisins=[(x, y+1), (x, y-1), (x+1, y), (x-1, y)]
			chem_carrefour=[(vx, vy) for vx, vy in voisins if (typecellule(vx, vy, dicojeu)!="mur" and (0<vx<=lignes) and (0<vy<=colonnes))]
			l=0
			while l<len(chem_carrefour):
				if chem_carrefour[l] in chemin:
					chem_carrefour.remove(chem_carrefour[l])
				else:
					l+=1
			if len(chem_carrefour)==0: #tous les chemins du carrefour sont dans la liste des chemins
				carrefours=[]
				chem_retour=[]
				copie=[]
				for i in chemin:
					if detection_nature_passage(i[0], i[1], dicojeu)=="Carrefour":
						carrefours.append(i)
				j=-2
				carrefour_actu=carrefours[-1]
				while carrefours[j]==carrefour_actu:
					j-=1
				carrefour_pre=carrefours[j]
				j=-1
				while chemin[j]!=carrefour_pre:
					j-=1
				posi=len(chemin)+j
				while chemin[posi]!=carrefour_actu:
					chem_retour.append(chemin[posi])
					posi+=1
				for i in range (len(chem_retour)//2):
					chem_retour[i], chem_retour[-1-i]=chem_retour[-1-i], chem_retour[i]

				x_prec=chemin[posi][0]
				y_prec=chemin[posi][1]

				for i in range (len(chem_retour)):
					if chem_retour[i][0]==x_prec:
						if chem_retour[i][1]==y_prec+1:
							copie.append('droite')
						elif chem_retour[i][1]==y_prec-1:
							copie.append('gauche')
					elif chem_retour[i][1]==y_prec:
						if chem_retour[i][0]==x_prec+1:
							copie.append('bas')
						elif chem_retour[i][0]==x_prec-1:
							copie.append('haut')
					x_prec=chem_retour[i][0]
					y_prec=chem_retour[i][1]
				suivre_commande(copie, t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
				for i in chem_retour:
					chemin.append(i)

			else :
				direc=random.choice(chem_carrefour)
				if direc==(x, y-1):
					gauche(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
				elif direc==(x, y+1):
					droite(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
				elif direc==(x-1, y):
					haut(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
				elif direc==(x+1, y):
					bas(t, t2, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li, label_pas, label_demi_tours, li_piece, label_points)
				chemin.append(direc)

		x=chemin[-1][0]
		y=chemin[-1][1]
	l=0
	i=0
	while l<len(chemin):
		if detection_nature_passage(chemin[l][0], chemin[l][1], dicojeu)=="Carrefour":
			ind_car=l
			i=l+1
			while i<len(chemin) and chemin[i]!=chemin[ind_car] :
				i+=1
			if i==len(chemin):
				l=len(chemin)
			else:
				del chemin[ind_car: i]
		l+=1
	
	chemin_lettre=[]
	x_prec=chemin[0][0]
	y_prec=chemin[0][1]
	for k in range (1, len(chemin)):
		if chemin[k][0]==x_prec:
			if chemin[k][1]==y_prec+1:
				chemin_lettre.append("droite")
			elif chemin[k][1]==y_prec-1:
				chemin_lettre.append("gauche")
		elif chemin[k][1]==y_prec:
			if chemin[k][0]==x_prec+1:
				chemin_lettre.append("bas")
			elif chemin[k][0]==x_prec-1:
				chemin_lettre.append("haut")
		x_prec=chemin[k][0]
		y_prec=chemin[k][1]
	
	return chemin_lettre
