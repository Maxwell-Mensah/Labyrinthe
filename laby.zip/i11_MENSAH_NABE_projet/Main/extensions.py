from navigation import *
from affichage import *


def recommencer(t, t2, nombre_pas ,temps_exploration ,nombre_demi_tours, dicojeu, label_pas, label_temps, label_demi_tours):

    # fonction du bouton recommencer
    coor_entré=dicojeu["Entré"]
    nombre_pas = 0
    temps_exploration = 0
    nombre_demi_tours = 0
    label_pas.config(text="Nombre de pas : 0" )
    label_demi_tours.config(text="Nombre de demi-tours : 0" )
    t.speed(100)
    pos=t.position()
    coor_pos=pixel2cell(int(pos[0]), int(pos[1]), dicojeu)
    if coor_pos==(dicojeu["Sortie"][0]+1, dicojeu["Sortie"][1]+1 ):
        t2.undo()
    t.hideturtle()
    t.goto(cell2pixel(coor_entré[0]+1, coor_entré[1]+1, dicojeu))
    t.showturtle()
    


def quitter(root):
    # fonction du bouton quitter

   root.destroy()


def mise_a_jour_statistiques(label_pas, label_demi_tours,label_points, nombre_pas, nombre_demi_tours, points):
    #fonction qui met a jour les satatistiques de jeu
    label_points.config(text=f"Points : {points}")
    label_pas.config(text=f"Nombre de pas : {nombre_pas}")
    label_demi_tours.config(text=f"Nombre de demi-tours : {nombre_demi_tours}")

