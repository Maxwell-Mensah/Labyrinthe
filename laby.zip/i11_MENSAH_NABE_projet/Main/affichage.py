import math
import random


def afficheTextuel(lab):
    labyrinthe=lab[0]
    entré=lab[1]
    sortie=lab[2]
    for i in range (len(labyrinthe)):
        for j in range(len(labyrinthe[0])):
            if labyrinthe[i][j]==1:
                print("#", end="")
            elif labyrinthe[i][j]==0:
                if entré==[i, j]:
                    print("x", end="")
                elif sortie==[i, j]:
                    print("o", end="")
                else:
                    print(" ", end="")
        print()


def dessiner_case(x, y,  couleur, t, colonnes, lignes, taille):

    ## fonction pour dessiner chacune des cases du labyrinthe
    
    t.hideturtle()
    t.speed(1000)
    t.up()
    t.goto(x * taille - (colonnes * taille) // 2, (lignes * taille) // 2 - y * taille)
    t.down()
    t.begin_fill()
    t.fillcolor(couleur)
    for i in range(4):
        t.forward(taille)
        t.right(90)
    t.end_fill()



def afficheGraphique(t, dicojeu):

    ##fonction pour dessiner mon labyrinthe

    lignes=len(dicojeu["labyrinthe"])
    colonnes=len(dicojeu["labyrinthe"][0])
    taille=dicojeu["taille_cel"]
    for x in range (lignes):
        for y in range (colonnes):
            if dicojeu["labyrinthe"][x][y]==1:
                dessiner_case(y, x, "black", t, colonnes, lignes, taille)
            elif dicojeu["labyrinthe"][x][y]==0:
                dessiner_case(y, x, "white", t, colonnes, lignes, taille)
    dessiner_case(dicojeu["Entré"][1], dicojeu["Entré"][0], "lime", t, colonnes, lignes, taille)
    dessiner_case(dicojeu["Sortie"][1], dicojeu["Sortie"][0], "skyblue", t, colonnes, lignes, taille)


def pixel2cell(x, y,dicojeu):

    #fonction qui renvoie la ligne et la colonne en prenant en entré des coordonnées en pixel

    lignes=len(dicojeu["labyrinthe"])
    colonnes=len(dicojeu["labyrinthe"][0])
    taille=dicojeu["taille_cel"]
    xp=(x+(colonnes*taille/2))
    if y-(lignes*taille/2) < 0:
        yp=abs(y-(lignes*taille/2))
    else:
        yp=-1
    a=math.ceil(xp/taille)
    b=math.ceil(yp/taille)
    return b, a


def testclic(x, y,dicojeu):

    #fonction qu prend en entrer des coordonnées en pixel et renvoie les coordonées de la case en ligne et colonnes et qui affiche hors labyrinthe si ses coordonnées ne sont pas dans le labyrinthe

    coord_clic=pixel2cell(x, y, dicojeu)
    if 1<=coord_clic[0]<=lignes and 1<=coord_clic[1]<=colonnes:
        return (coord_clic)
    else:
        print("Hors labyrinthe")
    

def cell2pixel(i, j, dicojeu):

    # fonction qui prend en argument les coordonnées d'une  case et renvoie les coordonées en pixel du centre de la case
    xcsg=dicojeu["coor_csg"][0]
    ycsg=dicojeu["coor_csg"][1]
    taille=dicojeu["taille_cel"]
    pix1=(xcsg+(xcsg+taille))//2
    pix2=(ycsg+(ycsg-taille))//2
    return pix1+(taille*(j-1)), pix2-(taille*(i-1))

def casesbonus(dicojeu):
    cases_vides=[]
    for i in range(len(dicojeu["labyrinthe"])):
        for j in range(len(dicojeu["labyrinthe"][0])):
            if dicojeu["labyrinthe"][i][j]==0 and [i, j]!=dicojeu["Entré"] and [i, j]!=dicojeu["Sortie"]:
                cases_vides.append((i+1, j+1))
    return cases_vides

def dessine_piece(x, y, t, dicojeu):
    # Dessiner un cercle doré
    t.penup()
    t.goto(x, y-dicojeu["taille_cel"]//4)  # Centre le cercle au milieu de l'écran
    t.pendown()
    t.color("gold")
    t.begin_fill()
    t.circle(10)  # Rayon de 100
    t.end_fill()
    
    # Ajouter un contour noir
    t.color("black")
    t.pensize(0.5)
    t.circle(10)  # Repasser sur le contour

    # Ajouter un effet de brillance (petit cercle blanc)
    t.penup()
    t.goto(x+2, y+2)
    t.pendown()
    t.color("white")
    t.begin_fill()
    t.circle(2)
    t.end_fill()

    # Terminer le dessin


def positionnement_points(t, dicojeu):
    n=casesbonus(dicojeu)
    deja=[]
    for i in range (len(n)//4):
        a=random.choice(n)
        while a in deja:
            a=random.choice(n)
        r=cell2pixel(a[0], a[1], dicojeu)
        dessine_piece(r[0], r[1], t, dicojeu)
        deja.append(a)
    return deja

def typecellule(x, y, dicojeu):

    # fonction qui prend en entre les coordonnées d'une case et renvoie le type de la case(passeg, carrefour, impasse)

    lab=dicojeu["labyrinthe"] ##labyrinthe
    lab_e=dicojeu["Entré"] #coordonnées entré
    lab_s=dicojeu["Sortie"] ##coordonées sortie
    lignes=len(lab)
    colonnes=len(lab[0])

    if (0<x<=lignes) and (0<y<=colonnes):
        if lab[x-1][y-1]==1:  ## on fait x-1 et y-1 a ce niveau parcequ'on veut que  nos lignes et nos colonnes 
            return "mur"      ##commencent par 1 et non pas par 0 nos x et nos y seront toujours supérieur a zero
        elif lab[x-1][y-1]==0: 
            if lab_e==[x-1, y-1]:
                return "entré"
            elif lab_s==[x-1, y-1]:
                return "sortie"
            return "passage"

def detection_nature_passage(x, y, dicojeu):

    # fonction qui prend en entre les coordonnées d'un passage et renvoie la nature de la case (carrefour, passage standard, impasse)

    lignes=len(dicojeu["labyrinthe"])
    colonnes=len(dicojeu["labyrinthe"][0])

    voisins=[(x, y+1), (x, y-1), (x+1, y), (x-1, y)] #la liste des coordonnées des cases autour de la case en question
    passages=sum(1 for vx, vy in voisins if (typecellule(vx, vy, dicojeu)!="mur" and (0<vx<=lignes) and (0<vy<=colonnes)))
    if passages==1:
        return "Impasse"
    elif passages==2:
        if (typecellule(x, y+1, dicojeu)=="passage" and typecellule(x, y-1, dicojeu)=="passage") or(typecellule(x+1, y, dicojeu)=="passage" and typecellule(x-1, y, dicojeu)=="passage"):
            return "Passage standard"
        else:
            return "angle"
    elif passages>=3:
        return "Carrefour"


def dessin_carrefour(dicojeu, t): 

    # fonction qui dessine les carrefours de mon labyrinthe en couleur or
    lignes=len(dicojeu["labyrinthe"])
    colonnes=len(dicojeu["labyrinthe"][0])
    taille=dicojeu["taille_cel"]
    nombre_carrefours=0
    for i in range(1, lignes):
        i_mod=i+1 ##on fait + 1 pour fait correspondre nos valeurs avec ce que notre fonction type cellule doit recevoir
        for j in range(1, colonnes):
            j_mod=j+1  ##on fait + 1 pour fait correspondre nos valeurs avec ce que notre fonction type cellule doit recevoir
            if (typecellule(i_mod, j_mod, dicojeu)=="passage") and (detection_nature_passage(i_mod, j_mod, dicojeu)=="Carrefour"):
                nombre_carrefours+=1
                dessiner_case(j, i, "gold", t, colonnes, lignes, taille) #on fait dessiner case j, i parceque notre nos 
    return nombre_carrefours                #lignes sont calculées avec l'ordonnée et nos colonnes sont calculés par l'absisse


def impasses(dicojeu):

    ##compte le nombre d'impasse dans le labyrinthe 
    lignes=len(dicojeu["labyrinthe"])
    colonnes=len(dicojeu["labyrinthe"][0])
    nombre_impasses=0
    for i in range(1, lignes):
        i_mod=i+1
        for j in range(1, colonnes):
            j_mod=j+1
            if (typecellule(i_mod, j_mod, dicojeu)=="passage") and (detection_nature_passage(i_mod, j_mod, dicojeu)=="Impasse"):
                nombre_impasses+=1
    return nombre_impasses