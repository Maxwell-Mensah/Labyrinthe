"""
-----------------------------------------------------------------------------
MENSAH_NABE_projet.py : CR projet « Labyrinthe», groupe ima10-X
-----------------------------------------------------------------------------
"""


from lireLaby import labyFromFile
import os
import math
from turtle import *
from tkinter import *
from affichage import *
from navigation import *
from extensions import * 
import random

###############################################initialisation du programme######################################################

taille=40 ##Taille de mes cellules

couleur_de_tortue="black" #couleur de ma tortue par défaut

fn=input("Entrez le nom du fichier du labyrinthe:") ###veillez mettre a ce niveau le chemin d'accès complet vers le fichier de destination

info=labyFromFile(fn)

xcsg=-(len(info[0][0]) * taille) // 2 #abcise coin supérieur gauche
ycsg=(len(info[0]) * taille) // 2 #ordonné coin supérieur gauche

print(info) ## La liste de liste contenant la liste du labyrinthe , les coordonnées de l'entré et les coordonnées de la sortie

dicojeu={"labyrinthe":info[0],
         "Entré": info[1],
          "Sortie": info[2],
           "coor_csg" : (xcsg, ycsg),
           "taille_cel": taille,
           "couleur de tortue": couleur_de_tortue} ## Dictionnaire dicojeu contenant toutes les informations utiles aux différentes fonctions du jeu

#################################################################les frame qui permettent la fusion de la fenêtre turtle avec tkinter##############################################################

# Fenêtre principale avec Tkinter
root = Tk()
root.title("Labyrinthe fun")

frame_boutons=Frame(root, width=800, height=50, bg="lightgray")
frame_boutons.pack(side=TOP, fill=X)

#Création d'un cadre pour centrer le Canvas
frame=Frame(root, width=800, height=500, bg="blue")
frame.pack()

# Cadre pour Turtle
canva = Canvas(frame, width=800, height=600)
canva.pack(expand=True, fill=BOTH)

#Cadre pour statistiques
frame_stats=Frame(root, width=800, height=100, bg="lightgray")
frame_stats.pack(side=TOP, fill=X)

##############################################################"les statistiques de jeu###################################################

li_stat=[0, 0, 0] ##liste statistiques premier element nombre de pas , second element nombre de demi tours et troisième nombre de poiints
nombre_pas = 0
temps_exploration = 0
nombre_demi_tours = 0
nombre_impasses = 0
nombre_carrefours = 0
points=0
liste_commande=[]

######################################association de toutes les tortues dont on aura besoin a la fenêtre tkinter#############################

screen =TurtleScreen(canva)  # Associer l'écran à Tkinter
screen.bgcolor("white")               # Couleur de fond de la fenêtre Turtle
t =RawTurtle(screen)          # Créer une tortue attachée au canvas: tortue explorateur
t.speed(0)                            # Régler la vitesse de la tortue

t.hideturtle()
t2 =RawTurtle(screen)          # Créer une tortue attachée au canvas: tortue message victoire
t2.speed(0)
t2.hideturtle() 
t3 =RawTurtle(screen)          # Créer une tortue attachée au canvas; tortue message impossible d'évoluer fonction suivre commande
t3.speed(0)
t3.hideturtle()
t4 =RawTurtle(screen)          # Créer une tortue attachée au canvas: tortue message d'erreur dans la fenêtre turtle
t4.speed(0)
t4.hideturtle()
t5 =RawTurtle(screen)          # Créer une tortue attachée au canvas: tortue course
t5.speed(0)
t5.hideturtle()
#################################################definition des fonctions de nos boutons############################################################

def recom():  #bouton recommencer
    global temps_exploration, li_stat, posi_pieces, copie, liste_commande
    liste_commande=[]
    t3.undo()
    t3.hideturtle()
    posi_pieces=list(copie)
    temps_exploration=0
    li_stat=[0, 0, 0]
    label_temps.config(text=f"Nombre de pas : {li_stat[0]}")
    label_temps.config(text=f"Nombre de demi-tours : {li_stat[1]}")
    label_points.config(text=f"Points : {li_stat[2]}")
    label_temps.config(text=f"Temps d'exploration : {temps_exploration} s")
    recommencer(t, t2, nombre_pas ,temps_exploration ,nombre_demi_tours, dicojeu, label_pas, label_temps, label_demi_tours)
    t5.hideturtle()
    for i in posi_pieces:
        r=cell2pixel(i[0], i[1], dicojeu)
        t4.color("black")
        dessine_piece(r[0], r[1], t4, dicojeu)
    


def expl(): #bouton exploration automatique
    explorer(t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, posi_pieces, label_points, dicojeu["Entré"], dicojeu["Sortie"])

def quite(): #bouton quitter
    quitter(root)

def course(): #bouton course entre les deux tortues
    global temps_exploration
    explorer(t, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, posi_pieces, label_points, dicojeu["Entré"], dicojeu["Sortie"])
    temps_1=temps_exploration
    temps_exploration=0 ##ramène le temps a zero avant le départ de la seconde tortue
    augu()  
    explorer(t5, t2, t3, t4, dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat, label_pas, label_demi_tours, posi_pieces, label_points, dicojeu["Sortie"], dicojeu["Entré"])
    temps_2=temps_exploration
    if temps_1<temps_2:
        t3.up()
        t3.goto(0, -280)
        t3.color("black")
        t3.down()
        t3.write(f"Vainqueur tortue 1 avec un temps de {temps_1} secondes", align="center", font=("Arial", 11, "bold"))
    else:
        t3.up()
        t3.goto(0, -280)
        t3.color("black")
        t3.down()
        t3.write(f"Vainqueur tortue 2 avec un temps de {temps_2} secondes", align="center", font=("Arial", 11, "bold"))
    global repet
    root.after_cancel(repet)
    

#####################"mise a jour temps############################################
def mise():

    ## fonction qui met a jour le temps

    global temps_exploration, dicojeu
    pos=t.position()
    coor=(pixel2cell(int(pos[0]), int(pos[1]), dicojeu))
    if [coor[0]-1, coor[1]-1]!=dicojeu["Sortie"]:
        temps_exploration+=1
    label_temps.config(text=f"Temps d'exploration : {temps_exploration} s")
    root.after(1000, mise)

repet=None

def augu():

    ##fonction qui met a jour le temps de la seconde tortue pendant la course

    global temps_exploration, dicojeu, repet
    pos=t5.position()
    coor=(pixel2cell(int(pos[0]), int(pos[1]), dicojeu))
    if [coor[0]-1, coor[1]-1]!=dicojeu["Entré"]:
        temps_exploration+=1
    label_temps.config(text=f"Temps d'exploration : {temps_exploration} s")
    repet=root.after(1000, augu)


################################################positionnement de mes boutons######################################################


btn_jouer = Button(frame_boutons, text="Recommencer", command=recom, bg="green", fg="white", font=("Arial", 14, "bold"), relief="ridge", bd=2)


btn_explorer = Button(frame_boutons, text="Exploration automatique", command=expl, bg="green", fg="white", font=("Arial", 14, "bold"), relief="ridge", bd=2)

btn_quitter = Button(frame_boutons, text="Quitter", command=quite, bg="green", fg="white", font=("Arial", 14, "bold"), relief="ridge", bd=2)

btn_course = Button(frame_boutons, text="Course", command=course, bg="green", fg="white", font=("Arial", 14, "bold"), relief="ridge", bd=2)



btn_jouer.pack(side=LEFT, padx=20, pady=20)

Label(bg="lightgray").pack(padx=50)

btn_quitter.pack(side=RIGHT, padx=20, pady=20)

btn_explorer.pack(side=LEFT, padx=20, pady=20)
btn_course.pack(side=RIGHT, padx=20, pady=20)


#############################positionnement des textes de mes statistiques de jeu###############################################################

label_pas = Label(frame_stats, text="Nombre de pas : 0", font=("Arial", 12), bg="lightgray")
label_pas.pack(side=LEFT, padx=20)
label_temps = Label(frame_stats, text=f"Temps d'exploration : {temps_exploration} secondes", font=("Arial", 12), bg="lightgray")
label_temps.pack(side=LEFT, padx=20)
label_demi_tours = Label(frame_stats, text="Nombre de demi-tours : 0", font=("Arial", 12), bg="lightgray")
label_demi_tours.pack(side=LEFT, padx=20)
Label(bg="lightgray").pack(padx=100)
label_impasses = Label(frame_stats, text=f"Nombre d'impasses : {nombre_impasses}", font=("Arial", 12), bg="lightgray")
label_impasses.pack(side=RIGHT, padx=20)
label_carrefours = Label(frame_stats, text=f"Nombre de carrefours : {nombre_carrefours}", font=("Arial", 12), bg="lightgray")
label_carrefours.pack(side=RIGHT, padx=20)
label_points = Label(frame_stats, text=f"Points : {points}", font=("Arial", 12), bg="lightgray")
label_points.pack(side=RIGHT, padx=20, pady=20)

##############################################affichage du labyrinthe################################################################################

afficheGraphique(t, dicojeu)

nombre_carrefours=dessin_carrefour(dicojeu, t) #dessine les carrefours en or en renvoie le nombre de carrefours

nombre_impasses=impasses(dicojeu) ##renvois le nombres d'impasses dans la labyrinthe

posi_pieces=positionnement_points(t, dicojeu) #dessine les pièces et retoUrne les positions de chaque pièces########################################
copie=list(posi_pieces) ###pour pouvoir récréer les pièces quand l'utilisateur appuie sur le bouton recommencer


label_impasses.config(text=f"Nombre d'impasses : {nombre_impasses}") 
label_carrefours.config(text=f"Nombre de carrefours : {nombre_carrefours}")


#############################################positionnenement de la tortue a l'entrée################################################################""
t.color(couleur_de_tortue)
t.shape("turtle")
t.up()
coor_entré=[dicojeu["Entré"][0]+1, dicojeu["Entré"][1]+1]
t.goto(cell2pixel(coor_entré[0], coor_entré[1], dicojeu))
t.showturtle()

t5.shape("turtle")
t5.color("yellow")
t5.up()


##########################################les fonctions de deplacement##########################################################

def g():
    gauche(t, t2, t4,  dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen,li_stat, label_pas, label_demi_tours, posi_pieces, label_points)
    
def d():
    droite(t, t2, t4,  dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen,li_stat, label_pas, label_demi_tours, posi_pieces, label_points)

def h():
    haut(t, t2, t4,  dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen,li_stat, label_pas, label_demi_tours, posi_pieces, label_points)

def b():
    bas(t, t2, t4,  dicojeu, nombre_pas, nombre_demi_tours, liste_commande, screen, li_stat,  label_pas, label_demi_tours, posi_pieces, label_points)

# Contrôle tortue
screen.onkeypress(g,"Left")
screen.onkeypress(d,"Right")
screen.onkeypress(h,"Up")
screen.onkeypress(b,"Down")
screen.listen()




mise()

mainloop()